---
name: amzginstapost
description: Generate an Amazing Solutions branded Instagram post (1080x1440) in the AMZ style — green bubble background with a theme image centered behind the bubbles, serif pink title at top, divider bar with logo, and bold white caption at the bottom. Trigger IMMEDIATELY when Samuel says "amzginstapost", "amzinstapost", "post para amazing solutions", or "post de amazing". When triggered, ask exactly: "Una palabra para encabezado, dame foto, dame caption." then build the post once all three are provided.
---

# amzginstapost — Amazing Solutions Instagram Post Generator

## What this skill does

Generates a 1080x1440 Instagram post for **AmazingSolutions.ca** in a fixed editorial style.

**Every post has:**
- **Green bubble background** (fixed asset — always the same base with service bubbles)
- **Theme image** centered, background removed automatically, placed BEHIND the bubbles and ABOVE the dark shadow
- **Title** at top — P052 serif (Marcellus-style), sentence case, light pink, centered
- **Divider bar** in the dark zone: `———— [logo] amazingsolutions.ca ————`
- **Caption** below divider — Manrope ExtraBold, white, centered, -2 letter spacing, auto-fits

## What to ask Samuel

When this skill is triggered, ask exactly this — nothing more:

> "Una palabra para encabezado, dame foto, dame caption."

- **Encabezado** = the title word(s) — rendered in sentence case pink serif at the top
- **Foto** = the theme image — background removed automatically, placed behind bubbles
- **Caption** = short sentence for the dark bottom zone

Never ask more than these three things. Once you have all three, build immediately.

## How to run

```bash
python /mnt/skills/user/amzginstapost/scripts/create_post.py \
  --title "Inteligencia artificial." \
  --person "/mnt/user-data/uploads/photo.png" \
  --caption "La inteligencia artificial no reduce la cantidad de trabajo:" \
  --output "/mnt/user-data/outputs/amzginstapost-<slug>.png"
```

Pick a descriptive slug from the title for the filename.

## Layout rules — never change

| Zone | Element | Spec |
|------|---------|------|
| Top | Title | P052-Roman, 128px, sentence case, light pink `(255,180,195)`, centered, -1 letter spacing |
| Middle | Theme image | bg removed, scaled to fit between title and shadow (y=18%→y=1110), centered horizontally, behind bubbles |
| Dark zone | Divider | 44px logo + "amazingsolutions.ca" Bold 26px, horizontal rules each side |
| Dark zone | Caption | Manrope ExtraBold 58px, white, centered, -2 letter spacing, anchored 80px from bottom |

## Background removal

The script uses simple color-based removal (works for white/grey/checkered backgrounds).
For images with complex backgrounds, ask Samuel to pre-remove with **remove.bg** before uploading.

## Fixed assets (never replace without Samuel's approval)

```
amzginstapost/
├── SKILL.md
├── assets/
│   ├── background.png        ← green bubble background (1088x1445 source, resized to 1080x1440)
│   ├── logo_white.png        ← Amazing Solutions white logo (PNG with alpha)
│   └── fonts/
│       ├── Manrope-Bold.ttf
│       ├── Manrope-ExtraBold.ttf
│       ├── Manrope-Medium.ttf
│       └── Manrope-Thin.ttf
└── scripts/
    └── create_post.py
```

System serif font used: `/usr/share/fonts/opentype/urw-base35/P052-Roman.otf` (Palatino-style, closest to Marcellus available in sandbox).

## After generating

1. Use `present_files` to deliver the PNG.
2. Keep your message short — one sentence max.
3. Don't add post-amble explanations.
