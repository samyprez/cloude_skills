#!/usr/bin/env python3
"""
amzginstapost — Amazing Solutions Instagram Post Generator
Canvas: 1080x1440 px

Usage:
  python create_post.py \
    --title "Palabra" \
    --person /path/to/photo.jpg \
    --caption "El caption corto aqui" \
    --output /path/to/output.png

Layout (top to bottom):
  1. Title        — P052 serif, sentence case, light pink, centered top
  2. Person/image — bg removed, centered, behind bubbles, ABOVE dark shadow
  3. Dark shadow zone:
       a. Divider — ——— [logo] amazingsolutions.ca ———
       b. Caption — Manrope ExtraBold, white, centered, auto-fit
"""

import argparse, os, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import numpy as np

# ── PATHS ────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
ASSETS_DIR = SCRIPT_DIR.parent / "assets"
FONT_SERIF = str(ASSETS_DIR / "fonts" / "Marcellus-Regular.ttf")
FONT_BOLD  = str(ASSETS_DIR / "fonts" / "Manrope-Bold.ttf")
FONT_XBOLD = str(ASSETS_DIR / "fonts" / "Manrope-ExtraBold.ttf")
FONT_MED   = str(ASSETS_DIR / "fonts" / "Manrope-Medium.ttf")
LOGO_PATH  = str(ASSETS_DIR / "logo_white.png")
BG_PATH    = str(ASSETS_DIR / "background.png")

# ── CONSTANTS ────────────────────────────────────────────
CANVAS_W, CANVAS_H = 1080, 1440
MARGIN      = 55
LIGHT_PINK  = (255, 180, 195)
WHITE       = (255, 255, 255)
SHADOW_Y    = 1110       # person/image stays above this line
TITLE_SIZE  = 128
CAPTION_SIZE= 58
DIVIDER_GAP = 18         # gap between divider bottom and caption top


def log(m): print(f"[amzginstapost] {m}", flush=True)


# ── TEXT HELPERS ─────────────────────────────────────────
def measure(draw, text, font, sp=0):
    return sum(draw.textlength(c, font=font) + sp for c in text) - (sp if text else 0)

def draw_spaced(draw, xy, text, font, fill, sp=0):
    x, y = xy
    for c in text:
        draw.text((x, y), c, font=font, fill=fill)
        x += draw.textlength(c, font=font) + sp

def wrap_text(text, font, max_w, draw, sp=0):
    words = text.split()
    lines, current = [], words[0]
    for word in words[1:]:
        test = current + " " + word
        if measure(draw, test, font, sp) <= max_w:
            current = test
        else:
            lines.append(current)
            current = word
    lines.append(current)
    return lines


# ── BACKGROUND REMOVAL ───────────────────────────────────
def remove_bg_simple(path: str) -> Image.Image:
    """
    Always removes the background from any image:
    1. If image already has real alpha transparency → use it as-is.
    2. If background is white/grey/solid → remove by color proximity.
    """
    img = Image.open(path).convert("RGBA")
    arr = np.array(img, dtype=np.float32)

    # Check if image already has meaningful transparency (>2% transparent pixels)
    transparent_px = (arr[:,:,3] < 200).sum()
    total_px = arr.shape[0] * arr.shape[1]
    if transparent_px > total_px * 0.02:
        log(f"  Already transparent ({int(transparent_px)} px) — using existing alpha")
        return img

    # Otherwise detect and remove white/grey/solid background
    R, G, B = arr[:,:,0], arr[:,:,1], arr[:,:,2]
    is_bg = (R > 200) & (G > 200) & (B > 200) & \
            (np.abs(R-G) < 18) & (np.abs(G-B) < 18)
    arr[:,:,3] = np.where(is_bg, 0, 255)
    log(f"  Color-based removal: {int(is_bg.sum())} bg pixels removed")
    return Image.fromarray(arr.astype(np.uint8), "RGBA")


# ── COMPOSITE: person behind bubbles ─────────────────────
def composite_behind_bubbles(base: Image.Image, person: Image.Image,
                              robot_top: int) -> Image.Image:
    """Replace green pixels with person pixels — bubble whites stay on top."""
    ba = np.array(base, dtype=np.float32)
    ro = np.array(person, dtype=np.float32)
    H, W = ba.shape[:2]
    rh, rw = ro.shape[:2]

    rx0 = (W - rw) // 2
    ry0 = robot_top
    rc  = np.zeros((H, W, 4), dtype=np.float32)
    sx0=max(0,-rx0); sy0=max(0,-ry0)
    sx1=min(rw,W-rx0); sy1=min(rh,H-ry0)
    dx0=max(0,rx0); dy0=max(0,ry0)
    if sx1 > sx0 and sy1 > sy0:
        rc[dy0:dy0+(sy1-sy0), dx0:dx0+(sx1-sx0)] = ro[sy0:sy1, sx0:sx1]

    bR,bG,bB = ba[:,:,0],ba[:,:,1],ba[:,:,2]
    is_green  = (bG > bR+12) & (bG > bB+8) & (bG > 35)
    r_alpha   = rc[:,:,3] / 255.0
    result    = ba.copy()
    for c in range(3):
        result[:,:,c] = np.where(
            is_green & (r_alpha > 0.3),
            rc[:,:,c]*r_alpha + ba[:,:,c]*(1-r_alpha),
            ba[:,:,c])
    result[:,:,3] = 255
    return Image.fromarray(result.astype(np.uint8), "RGBA")


# ── MAIN ─────────────────────────────────────────────────
def create_post(title: str, person_path: str, caption: str, output_path: str):
    log(f"Starting — title='{title}'")
    log(f"Person: {person_path}")
    cw = CANVAS_W - 2 * MARGIN

    # 1. Remove background from person/theme image
    log("[10%] Removing background...")
    person = remove_bg_simple(person_path)
    robot_top   = int(CANVAS_H * 0.18)
    max_h       = SHADOW_Y - robot_top
    target_w    = int(person.width * max_h / person.height)
    person      = person.resize((target_w, max_h), Image.Resampling.LANCZOS)
    log(f"[25%] Person scaled to {person.size}, bottom at y={robot_top+max_h}")

    # 2. Load background (1080x1440)
    log("[30%] Loading background...")
    base = Image.open(BG_PATH).convert("RGBA")
    base = base.resize((CANVAS_W, CANVAS_H), Image.Resampling.LANCZOS)

    # 3. Composite person behind bubbles
    log("[40%] Compositing person behind bubbles...")
    canvas = composite_behind_bubbles(base, person, robot_top)
    draw   = ImageDraw.Draw(canvas)
    log("[55%] Composited")

    # 4. Title — sentence case, light pink serif, top
    log("[60%] Drawing title...")
    font_t = ImageFont.truetype(FONT_SERIF, TITLE_SIZE)
    # Split title into max 2 lines at natural break
    title_words = title.split()
    mid = len(title_words) // 2
    lines_t = [" ".join(title_words[:mid]), " ".join(title_words[mid:])] \
              if len(title_words) > 1 else [title]
    y = 30
    for line in lines_t:
        if not line.strip(): continue
        tw = measure(draw, line, font_t, -1)
        x  = MARGIN + (cw - tw) // 2
        draw_spaced(draw, (x+2, y+2), line, font_t, (0,35,15,130), -1)
        draw_spaced(draw, (x,   y),   line, font_t, LIGHT_PINK,    -1)
        y += int(TITLE_SIZE * 1.08)
    log("[68%] Title drawn")

    # 5. Caption measurement (anchor from bottom)
    log("[70%] Measuring caption...")
    font_c    = ImageFont.truetype(FONT_XBOLD, CAPTION_SIZE)
    cap_lines = wrap_text(caption, font_c, cw-10, draw, -2)
    line_h    = int(CAPTION_SIZE * 1.22)
    total_cap = len(cap_lines) * line_h
    cap_y     = CANVAS_H - 80 - total_cap   # anchor to bottom

    # 6. Divider — tight above caption
    log("[74%] Drawing divider...")
    logo = Image.open(LOGO_PATH).convert("RGBA")
    la   = np.array(logo); vis=la[:,:,3]>30
    la[vis,0]=la[vis,1]=la[vis,2]=255
    logo = Image.fromarray(la,"RGBA")
    lh   = 44
    lw_px= int(round(logo.width * lh / logo.height))
    logo = logo.resize((lw_px, lh), Image.Resampling.LANCZOS)

    font_brand = ImageFont.truetype(FONT_BOLD, 26)
    brand_text = "amazingsolutions.ca"
    brand_w    = int(measure(draw, brand_text, font_brand, 0))
    gap        = 12
    inner_w    = lw_px + gap + brand_w
    div_y      = cap_y - DIVIDER_GAP - lh
    line_cy    = div_y + lh // 2
    logo_x     = (CANVAS_W - inner_w) // 2

    draw.line([(MARGIN, line_cy), (logo_x-gap, line_cy)],
              fill=(255,255,255,160), width=2)
    canvas.alpha_composite(logo, (int(logo_x), int(div_y)))
    bbox  = draw.textbbox((0,0),"Ag",font=font_brand)
    txt_h = bbox[3]-bbox[1]
    txt_y = div_y + (lh-txt_h)//2
    draw_spaced(draw, (logo_x+lw_px+gap, txt_y), brand_text, font_brand, WHITE, 0)
    draw.line([(logo_x+inner_w+gap, line_cy), (CANVAS_W-MARGIN, line_cy)],
              fill=(255,255,255,160), width=2)
    log("[82%] Divider drawn")

    # 7. Caption — ExtraBold, white, centered, -2 spacing
    log("[85%] Drawing caption...")
    y = cap_y
    for line in cap_lines:
        lw = measure(draw, line, font_c, -2)
        x  = MARGIN + (cw - lw) // 2
        draw_spaced(draw, (x, y), line, font_c, WHITE, -2)
        y += line_h
    log(f"[93%] Caption: {CAPTION_SIZE}px ExtraBold, {len(cap_lines)} lines")

    # 8. Save
    canvas.convert("RGB").save(str(output_path), "PNG", optimize=True)
    log(f"[100%] Saved: {output_path}")


def main():
    p = argparse.ArgumentParser(description="amzginstapost — Amazing Solutions post generator")
    p.add_argument("--title",   required=True,  help="One-word or short title (sentence case, pink)")
    p.add_argument("--person",  required=True,  help="Theme image path (bg will be removed)")
    p.add_argument("--caption", required=True,  help="Short caption text for dark bottom zone")
    p.add_argument("--output",  required=True,  help="Output PNG path")
    a = p.parse_args()
    if not os.path.exists(a.person):
        print(f"[amzginstapost] ERROR: Person image not found: {a.person}")
        sys.exit(1)
    create_post(a.title, a.person, a.caption, a.output)

if __name__ == "__main__":
    main()
