---
name: todoinstapost
description: Generate a Toronto Dominicano-branded Instagram post (1080x1350) in the exact recurring TODO style — Manrope Bold headline at top with tight letter spacing, the user's photo centered in the middle with subtle rounded corners, "TORONTO DOMINICANO / TODOMINICANO.COM" letter-spaced text bottom-left, and the TODOMINICANO logo with "@todominicano" handle bottom-right on a clean white background. **Trigger this skill IMMEDIATELY whenever Samuel says "todoinsta"** — that's his shortcut to start a new post. Also trigger on phrases like "create an Instagram post", "make a TODO post", "haz un post de TODO", "Instagram graphic for an article", or any request involving 1080x1350 portrait social images for the Toronto Dominicano brand, even if he doesn't say "todoinstapost" by name.
---

# todoinstapost — Toronto Dominicano Instagram Post Generator

## What this skill does

This skill produces Instagram-ready post images for **TorontoDominicano.com** in a single, locked-in visual style so every post in the feed looks consistent.

**Every output is:**
- Exactly **1080 x 1350 px** (Instagram portrait, 4:5)
- White background
- **Manrope Bold** headline at top, **center-aligned**, **fixed 72px font size** on every post, with **-2 letter spacing** (tight compressed editorial look)
- The user's photo, **fixed at 860 x 780 px**, centered horizontally (white space on the sides), positioned at a **fixed Y=380**, with subtle rounded corners (object-fit: cover)
- **TORONTO DOMINICANO** and **TODOMINICANO.COM** in Manrope Medium, letter-spaced +3px in the bottom-left
- A **logo + handle lockup** in the bottom-right corner: the TODOMINICANO logo (100px tall, transparent background) on top, with **@todominicano** in Manrope Medium 22px directly below it. Both right-aligned at the canvas right margin.

The bottom branding text and the logo are **fixed brand elements** — never change them.

## What to ask Samuel for

When this skill is triggered, Samuel needs to provide exactly two things:

1. **The title** — the headline that goes at the top of the post
2. **The image** — the main photo (usually attached as a file upload; accept JPG, PNG, or WebP)

### How to respond based on what Samuel said

- **If Samuel said only "todoinsta"** (the shortcut trigger) and provided nothing else: respond with exactly this short message in Spanish, and stop — wait for his next message with the title and photo:

  > "Dame el título y la foto."

- **If Samuel said "todoinsta" plus a title and attached a photo**: don't ask anything, just build the post immediately.

- **If Samuel provided one of the two but not the other**: ask only for the missing piece, in friendly Spanish (per Samuel's preferences: friendly teacher tone, no emojis unless he uses them first).

- **If Samuel triggered the skill via natural language** (e.g. "make me a TODO post about X") and provided everything inline: just build it.

Never ask both questions at once if he already gave you one of them. Never ask if he already gave you both.

## How to generate the post

Run the bundled script `scripts/create_post.py`. It handles all the layout, font fitting, image cropping, and compositing.

**Always save the output to `/mnt/user-data/outputs/`** so Samuel can download it via the `present_files` tool afterward.

```bash
python /path/to/todoinstapost/scripts/create_post.py \
  --title "The exact title Samuel gave" \
  --image "/mnt/user-data/uploads/the-image-he-uploaded.jpg" \
  --output "/mnt/user-data/outputs/todo-post-<short-descriptive-slug>.png"
```

Pick a descriptive slug for the output filename based on the title (e.g. `todo-post-bad-bunny-met-gala.png`) so Samuel can tell posts apart in his Downloads folder.

The script prints visible progress messages with percentage counters as it runs — this matches Samuel's preference for real-time progress reports on long tasks.

## After generating

1. Use `present_files` to deliver the PNG to Samuel.
2. Keep your summary short — one or two sentences max. He just wants the file.
3. Don't post-amble with a long explanation; he can see the image himself.

## Design rules — do not deviate

These are hard-locked so every post looks like part of the same series:

- **Canvas size:** 1080 x 1350 only. Never resize, never change ratio.
- **Background:** Pure white (#FFFFFF).
- **Title font:** Manrope Bold, bundled at `assets/fonts/Manrope-Bold.ttf`. Color: near-black (#0F0F0F). **Fixed 72px** on every post — never auto-shrink. **Center-align** each line. **Letter spacing -2** (tight compressed look).
- **Image:** Fixed **860 x 780 px**, centered horizontally (left x=110), at fixed Y=380. Slight rounded corners (18px radius), object-fit: cover.
- **Bottom text:** Manrope Medium, 26px, letter-spaced +3px, uppercase, exact strings "TORONTO DOMINICANO" and "TODOMINICANO.COM". Left-aligned at canvas margin.
- **Logo + handle lockup:** Logo bundled at `assets/logo.png` (transparent PNG), **100px tall**, width auto-scaled. Beneath it, the handle "@todominicano" in Manrope Medium **22px, letter-spacing 0**. Both elements are right-aligned at the canvas right margin (x=1020). The whole lockup sits in the bottom-right corner of the canvas, not overlapping the photo.
- **Margins:** 60px outer margin on all sides.

If Samuel asks for a one-off variation ("can you make this one with a black background?") it's fine to make that single exception — but **never change the bundled defaults**. The point of this skill is consistency across his feed.

## Editing the brand (rare)

If Samuel says he wants to permanently change something (new logo, different bottom text, etc.), update the relevant constant at the top of `scripts/create_post.py` or replace the asset file in `assets/`. Confirm the change with him before committing.

## Bundled assets

```
todoinstapost/
├── SKILL.md                           (this file)
├── assets/
│   ├── logo.png                       (TODOMINICANO.COM logo, transparent PNG, used bottom-right)
│   └── fonts/
│       ├── Manrope-Bold.ttf           (title font)
│       ├── Manrope-Medium.ttf         (bottom text font)
│       ├── Manrope-ExtraBold.ttf      (alternate weight, available if needed)
│       └── Manrope-Thin.ttf           (alternate weight, available if needed)
└── scripts/
    └── create_post.py                 (the image generator)
```

The script depends only on **Pillow** (PIL), which is pre-installed in Claude's sandbox environment.
