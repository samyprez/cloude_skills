#!/usr/bin/env python3
"""
todoinstapost - Toronto Dominicano Instagram post generator
Creates a 1080x1350 portrait post in the consistent TODO brand style.

Usage:
    python create_post.py --title "Your headline here" --image /path/to/photo.jpg --output /path/to/output.png

Output: a PNG file at the specified output path.
"""

import argparse
import os
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

# ============================================================
# BRAND CONSTANTS — locked in, do not change for visual consistency
# ============================================================
CANVAS_W, CANVAS_H = 1080, 1350         # Instagram portrait size
BG_COLOR = (255, 255, 255)              # white background
TEXT_COLOR = (15, 15, 15)               # near-black for body/title
MARGIN = 60                              # outer margin on all sides
IMAGE_CORNER_RADIUS = 18                 # subtle rounded corners on the photo

# Title block (Manrope Bold, fixed size, centered, tight letter-spacing)
TITLE_FONT_SIZE = 72                     # fixed — every post uses this exact size
TITLE_LINE_SPACING = 1.08
TITLE_LETTER_SPACING = -2                # negative spacing = tight compressed look
TITLE_TOP_Y = MARGIN                     # y position where title starts

# Image area (fixed size & position, like the original template)
IMAGE_W = 860                            # narrower than canvas — white space on sides
IMAGE_H = 780                            # shorter than v3 — more breathing room
IMAGE_TOP_Y = 380                        # fixed y position regardless of title length
IMAGE_LEFT_X = (CANVAS_W - IMAGE_W) // 2 # centered horizontally

# Bottom branding block
BOTTOM_BLOCK_HEIGHT = 90
BOTTOM_TEXT_SIZE = 26
BOTTOM_TEXT_LETTER_SPACING = 3           # positive — wide spaced uppercase
BOTTOM_LINE_GAP = 10
LOGO_TARGET_HEIGHT = 100                 # slightly smaller now since URL goes below

# Logo URL lockup (handle text under the logo)
URL_TEXT = "@todominicano"
URL_FONT_SIZE = 33                       # 1.5x bigger (was 22)
URL_LETTER_SPACING = 0                   # natural spacing (URLs read as a token)
LOGO_URL_GAP = 2                         # tight gap — handle sits right under the logo

BOTTOM_TEXT_LINE_1 = "TORONTO DOMINICANO"
BOTTOM_TEXT_LINE_2 = "TODOMINICANO.COM"

# ============================================================
# Bundled assets
# ============================================================
SCRIPT_DIR = Path(__file__).resolve().parent
ASSETS_DIR = SCRIPT_DIR.parent / "assets"
FONT_TITLE_PATH = ASSETS_DIR / "fonts" / "Manrope-Bold.ttf"
FONT_BOTTOM_PATH = ASSETS_DIR / "fonts" / "Manrope-Medium.ttf"
LOGO_PATH = ASSETS_DIR / "logo.png"


def log(msg):
    print(f"[todoinstapost] {msg}", flush=True)


# ============================================================
# Letter-spaced text helpers (support negative spacing for tight titles)
# ============================================================
def measure_spaced_text(draw, text, font, letter_spacing):
    """Measure total width of text with custom letter spacing applied."""
    total = 0
    for ch in text:
        total += draw.textlength(ch, font=font) + letter_spacing
    if text:
        total -= letter_spacing  # remove trailing spacing
    return total


def draw_spaced_text(draw, xy, text, font, fill, letter_spacing):
    """Draw text with custom letter spacing (works for positive or negative values)."""
    x, y = xy
    for ch in text:
        draw.text((x, y), ch, font=font, fill=fill)
        x += draw.textlength(ch, font=font) + letter_spacing


def wrap_text_spaced(text, font, max_width, draw, letter_spacing):
    """Wrap text into lines that fit within max_width, accounting for letter spacing."""
    words = text.split()
    if not words:
        return [""]
    lines = []
    current = words[0]
    for word in words[1:]:
        test = current + " " + word
        if measure_spaced_text(draw, test, font, letter_spacing) <= max_width:
            current = test
        else:
            lines.append(current)
            current = word
    lines.append(current)
    return lines


# ============================================================
# Image helpers
# ============================================================
def rounded_rectangle_mask(size, radius):
    mask = Image.new("L", size, 0)
    draw = ImageDraw.Draw(mask)
    draw.rounded_rectangle((0, 0, size[0], size[1]), radius=radius, fill=255)
    return mask


def fit_image_into_box(img, box_w, box_h):
    """Resize and center-crop (object-fit: cover)."""
    img = img.convert("RGB")
    src_w, src_h = img.size
    src_ratio = src_w / src_h
    target_ratio = box_w / box_h
    if src_ratio > target_ratio:
        new_h = box_h
        new_w = int(round(new_h * src_ratio))
    else:
        new_w = box_w
        new_h = int(round(new_w / src_ratio))
    resample = Image.Resampling.LANCZOS
    img = img.resize((new_w, new_h), resample=resample)
    left = (new_w - box_w) // 2
    top = (new_h - box_h) // 2
    return img.crop((left, top, left + box_w, top + box_h))


# ============================================================
# Main builder
# ============================================================
def create_post(title, image_path, output_path):
    log(f"Starting build — title length: {len(title)} chars")
    log(f"Input image: {image_path}")

    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Input image not found: {image_path}")
    if not FONT_TITLE_PATH.exists():
        raise FileNotFoundError(f"Title font missing: {FONT_TITLE_PATH}")
    if not LOGO_PATH.exists():
        raise FileNotFoundError(f"Logo missing: {LOGO_PATH}")

    log("[10%] Inputs validated")

    canvas = Image.new("RGBA", (CANVAS_W, CANVAS_H), BG_COLOR + (255,))
    draw = ImageDraw.Draw(canvas)
    log("[20%] Canvas created (1080x1350, white)")

    # ----- Title: Manrope Bold, fixed 72px, centered, -2 letter spacing -----
    content_width = CANVAS_W - 2 * MARGIN
    title_font = ImageFont.truetype(str(FONT_TITLE_PATH), TITLE_FONT_SIZE)
    title_lines = wrap_text_spaced(title, title_font, content_width, draw, TITLE_LETTER_SPACING)
    log(f"[35%] Title wrapped — Manrope Bold {TITLE_FONT_SIZE}px, spacing {TITLE_LETTER_SPACING}, {len(title_lines)} line(s)")

    line_height = int(TITLE_FONT_SIZE * TITLE_LINE_SPACING)
    y = TITLE_TOP_Y
    for line in title_lines:
        line_w = measure_spaced_text(draw, line, title_font, TITLE_LETTER_SPACING)
        x = MARGIN + (content_width - line_w) // 2
        draw_spaced_text(draw, (x, y), line, title_font, TEXT_COLOR, TITLE_LETTER_SPACING)
        y += line_height
    log(f"[50%] Title drawn — centered with -2 letter spacing")

    # ----- Image: FIXED size 860x780, centered horizontally, fixed Y position -----
    user_img = Image.open(image_path)
    fitted = fit_image_into_box(user_img, IMAGE_W, IMAGE_H)
    mask = rounded_rectangle_mask((IMAGE_W, IMAGE_H), IMAGE_CORNER_RADIUS)
    canvas.paste(fitted, (IMAGE_LEFT_X, IMAGE_TOP_Y), mask=mask)
    image_bottom_y = IMAGE_TOP_Y + IMAGE_H
    image_right_x = IMAGE_LEFT_X + IMAGE_W
    log(f"[70%] Image placed: {IMAGE_W}x{IMAGE_H} at ({IMAGE_LEFT_X}, {IMAGE_TOP_Y})")

    # ----- Bottom-left text -----
    # Line 1 (brand name): Manrope Medium
    # Line 2 (website URL): Manrope Bold (heavier weight for emphasis)
    bottom_block_top = CANVAS_H - MARGIN - BOTTOM_BLOCK_HEIGHT
    bottom_font_medium = ImageFont.truetype(str(FONT_BOTTOM_PATH), BOTTOM_TEXT_SIZE)
    bottom_font_bold = ImageFont.truetype(str(FONT_TITLE_PATH), BOTTOM_TEXT_SIZE)
    line_bbox = draw.textbbox((0, 0), "Mg", font=bottom_font_medium)
    line_h = line_bbox[3] - line_bbox[1]
    total_text_h = line_h * 2 + BOTTOM_LINE_GAP
    text_start_y = bottom_block_top + (BOTTOM_BLOCK_HEIGHT - total_text_h) // 2

    draw_spaced_text(
        draw, (MARGIN, text_start_y),
        BOTTOM_TEXT_LINE_1, bottom_font_medium, TEXT_COLOR, BOTTOM_TEXT_LETTER_SPACING,
    )
    draw_spaced_text(
        draw, (MARGIN, text_start_y + line_h + BOTTOM_LINE_GAP),
        BOTTOM_TEXT_LINE_2, bottom_font_bold, TEXT_COLOR, BOTTOM_TEXT_LETTER_SPACING,
    )
    log("[85%] Bottom-left text drawn (line 1 Medium, line 2 Bold)")

    # ----- Logo + URL lockup: positioned in bottom-right corner -----
    # Logo on top, "torontodominicano.com" below it, both right-aligned at canvas margin.
    # No longer overlaps the photo — sits in the white area in the bottom-right corner.
    logo = Image.open(LOGO_PATH).convert("RGBA")
    logo_aspect = logo.width / logo.height
    logo_h = LOGO_TARGET_HEIGHT
    logo_w = int(round(logo_h * logo_aspect))
    logo = logo.resize((logo_w, logo_h), resample=Image.Resampling.LANCZOS)

    # URL text measurements
    url_font = ImageFont.truetype(str(FONT_BOTTOM_PATH), URL_FONT_SIZE)
    url_w = measure_spaced_text(draw, URL_TEXT, url_font, URL_LETTER_SPACING)
    url_bbox = draw.textbbox((0, 0), URL_TEXT, font=url_font)
    url_h = url_bbox[3] - url_bbox[1]

    # Anchor the whole lockup to the bottom-right corner of the canvas margin box
    canvas_right = CANVAS_W - MARGIN
    canvas_bottom = CANVAS_H - MARGIN

    # URL goes at the very bottom, right-aligned
    url_y_top = canvas_bottom - url_h
    url_x = canvas_right - url_w

    # Logo sits above the URL, right-aligned
    logo_y_top = url_y_top - LOGO_URL_GAP - logo_h
    logo_x = canvas_right - logo_w

    canvas.alpha_composite(logo, (logo_x, logo_y_top))
    draw_spaced_text(draw, (url_x, url_y_top), URL_TEXT, url_font, TEXT_COLOR, URL_LETTER_SPACING)
    log(f"[95%] Logo+URL lockup placed bottom-right: logo at ({logo_x},{logo_y_top}) size {logo_w}x{logo_h}, URL at ({url_x},{url_y_top})")

    output_path = str(output_path)
    canvas.convert("RGB").save(output_path, "PNG", optimize=True)
    log(f"[100%] Saved: {output_path}")
    return output_path


def main():
    parser = argparse.ArgumentParser(description="Generate a Toronto Dominicano Instagram post.")
    parser.add_argument("--title", required=True)
    parser.add_argument("--image", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    try:
        create_post(args.title, args.image, args.output)
    except Exception as e:
        log(f"ERROR: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
