---
name: elementor-cloner
description: >
  Clone any landing page into WordPress + Elementor as closely as possible.
  Samuel gives a URL, a screenshot, or both, and this skill produces a
  complete beginner-friendly rebuild blueprint: WordPress/Elementor setup
  checklist, full page anatomy (hero, menu, sections, spacing), exact colors
  (hex), fonts and sizes, image list to download, and every hover effect and
  animation with step-by-step "where to click" Elementor instructions written
  for someone who is NOT an Elementor expert. Trigger IMMEDIATELY when Samuel
  says "elementor cloner", "elementor cloning", "clone for elementor", "clonar
  para elementor", "clona esta página", "clone this landing page", "copy this
  page into elementor", or any request to recreate / copy a website's front page
  pixel by pixel inside WordPress with Elementor.
---

# elementor-cloner — Clone any landing page into WordPress + Elementor

## What this skill does

Samuel finds a landing page he loves. He gives you the **URL, a screenshot, or
both**. You hand back a single, easy-to-follow **rebuild blueprint** that lets
him recreate that page as closely as possible inside WordPress using Elementor —
even though he is **not an Elementor expert**, so every instruction must say
exactly where to click.

The skill runs in **two separate phases — never both at once:**

- **PHASE 1 — Homepage.** Setup + analyze the source + full rebuild blueprint.
  At the end you ask: "Are you happy with the homepage?" **Stop there and wait.**
- **PHASE 2 — Inner pages.** Only after he confirms the homepage is done. He
  names the inner pages (About Us, Contact, Products, Services...). The header
  and footer stay the same across every page; only the body content changes; and
  every page gets linked together through the menu.

Do not jump to Phase 2 on your own. Finish Phase 1, ask, and wait for his
go-ahead.

The Phase 1 blueprint always covers, in this order:

1. **Setup** — install WordPress, install Elementor, and the exact Elementor
   settings to flip on first.
2. **Page anatomy** — hero section, navigation menu, every content section,
   footer, and the spacing between them.
3. **Design specs** — exact colors (hex), fonts and sizes, spacing in pixels.
4. **Images** — the list of images to download and where each one goes.
5. **Hover effects + animations** — each one matched to an Elementor setting,
   with step-by-step menu paths.
6. **Finish flow** — ask if he's done and offer to help customize.

> Honesty rule: a true byte-for-byte copy is not always possible (some sites use
> custom code Elementor can't reproduce). Aim for the **closest match possible**
> and tell Samuel plainly when something needs a Custom HTML/CSS widget instead
> of a native Elementor control. Never pretend a result is pixel-perfect when it
> isn't.

## Tone (important)

Per Samuel's standing preferences: **super friendly, like a teacher talking to a
5th-grade student.** No emojis unless he uses them first. Short, clear steps. He
can read in English or Spanish — match the language he's writing in. If he asks
for the steps in Spanish, give the whole blueprint in Spanish.

## Step 1 — Ask for the source (only what's missing)

When triggered with nothing attached, respond with exactly this and stop:

> "Pásame el enlace de la página, una captura de pantalla, o las dos cosas. Con
> eso te armo el plano completo para copiarla en Elementor."
> _(Send me the page link, a screenshot, or both. With that I'll build you the
> full blueprint to copy it into Elementor.)_

- If he already gave a **URL**, don't ask for it again.
- If he already attached a **screenshot**, don't ask for it again.
- If he gave **both**, go straight to Step 2. Both together = best result
  (URL gives exact code values, screenshot confirms the visual layout).

## Step 2 — Analyze the source

### If Samuel gave a URL

1. Use the **web_fetch** tool on the URL. Ask for raw HTML when possible
   (`html_extraction_method: "markdown"` gives clean text; if you need the CSS
   detail, fetch again and keep the raw markup). Also fetch any obvious external
   stylesheet links you see (`<link rel="stylesheet" href="...">`) because most
   colors, fonts, spacing, hovers, and animations live there, not in the HTML.
2. Save the fetched HTML/CSS to a local file in the working dir, e.g.
   `/home/claude/page.html`. If you fetched a separate stylesheet, append it to
   the same file so the analyzer sees everything.
3. Run the bundled analyzer:

   ```bash
   python /mnt/skills/user/elementor-cloner/scripts/analyze_page.py /home/claude/page.html
   ```

   It prints live progress and produces a Markdown report with the color
   palette, fonts, sizes, spacing, page structure, image list, hover effects,
   transitions, and animations. Use that report as your raw material — **do not
   just paste it at Samuel.** Translate it into the friendly step-by-step
   blueprint below.

4. The sandbox network can't reach arbitrary sites from `bash`, so always fetch
   with the **web_fetch tool** (which can), then run the analyzer on the saved
   file.

### If Samuel gave a screenshot

You can see it directly. Read off:
- The overall layout (how many sections, top to bottom).
- The color palette (name the hex values you see as closely as you can).
- The fonts (identify the closest common Google Font — e.g. "looks like Poppins
  / Montserrat / a clean geometric sans").
- Approximate spacing and proportions (generous padding vs tight, full-width vs
  boxed).
- Visible hover/animation hints he mentions (he may describe them).

### If Samuel gave both

Use the URL analyzer report for **exact values** (hex, fonts, px) and the
screenshot to **confirm the visual layout and catch anything the code missed**.

## Step 3 — Deliver the blueprint

Write it in this exact order. Keep each step short. Every Elementor instruction
must name **where to click**, because Samuel is a beginner.

### Section A — One-time setup

```
SETUP CHECKLIST (do this once)

1. Install WordPress
   - In your hosting panel (Hostinger/cPanel) open "Auto Installer" → WordPress
     → Install. Pick your domain, set an admin user and password.

2. Install Elementor (free)
   - WordPress dashboard → Plugins → Add New → search "Elementor"
     → Install Now → Activate.
   - (Optional, for more controls) also install "Elementor Pro" if you have it —
     it unlocks more animations and the Theme Builder for the header/menu.

3. Use a blank, Elementor-friendly theme
   - Appearance → Themes → Add New → install "Hello Elementor" → Activate.
     This theme adds no styles of its own, so your clone looks exactly how you
     build it.

4. Turn on the modern layout engine
   - Elementor → Settings → Features → set "Flexbox Container" to Active → Save.
     (Containers are how modern Elementor builds sections — easier and matches
     real websites.)

5. Load the page's fonts
   - Elementor → Settings → leave default fonts, OR add the Google Font the
     original uses: we'll set it per-element in the steps below.

6. Make a blank page to build on
   - Pages → Add New → name it → on the right set Template to
     "Elementor Canvas" (full width, no header/footer) → Publish
     → click "Edit with Elementor".
```

### Section B — Page anatomy (top to bottom)

List every section in order, like a map, so he rebuilds it block by block:

```
PAGE MAP (build these as Containers, top to bottom)

1. HEADER / MENU BAR
   - Logo on the [left/center], menu links: [list them], button on the right: [text]
   - Background: [color], height: [~px], sticky on scroll? [yes/no]

2. HERO SECTION
   - Big headline: "[text]"  | sub-headline: "[text]"
   - Button(s): "[text]"
   - Background: [image / solid color / gradient]
   - Layout: [text left + image right / centered / full-bleed image]

3. [SECTION NAME] ... repeat for each section ...

N. FOOTER
   - Columns: [...], background: [color], links: [...]
```

### Section C — Design specs

```
COLORS (set these as your Global Colors)
- Elementor → top-left hamburger menu → Site Settings → Global Colors.
- Primary: #......  | Secondary: #......  | Accent: #......
- Text: #......  | Background: #......
  (Setting them as Global Colors means you pick them from a swatch everywhere.)

FONTS
- Headline font: [Name] — set per heading: click the heading → Style tab
  → Typography (pencil icon) → Family → pick [Name], Size [..px], Weight [..].
- Body font: [Name], Size [..px].

SPACING (use these padding/margin numbers)
- Section top/bottom padding: [..px]
- Gap between columns: [..px]
- Set padding: click a Container → Advanced tab → set Padding values.
```

### Section D — Images

```
IMAGES TO BRING OVER
- [image 1 url] → use in the HERO background
- [image 2 url] → use in [section]
How to add one: click the image/container → pick Choose Image / Background
→ Upload Files → drag the downloaded image in.
Tip: if you can't download from the source, screenshot it or find a similar
free image on Pexels/Unsplash.
```

### Section E — Hover effects & animations (the part Samuel cares about)

For **each** effect the analyzer found (or you saw), give the closest Elementor
recreation with the full click path. Use this translation table:

| What the original does | Elementor recreation | Beginner click-path |
|---|---|---|
| Button/image grows on hover | Hover Animation: **Grow** | Click element → **Style** tab → Hover Animation dropdown → choose **Grow** |
| Button shrinks/pulses | Hover Animation: **Shrink** / **Pulse** | same dropdown → **Shrink** or **Pulse** |
| Element slides/moves up on hover | Hover Animation: **Float** / **Bob** | same dropdown → **Float** |
| Color change on hover (button) | Button **Hover** color | Click button → Style tab → switch to the **Hover** sub-tab → set Text/Background color |
| Image zoom inside its frame on hover | CSS Filters / scale on hover | Click image → Style → Hover sub-tab → set **CSS Transform → Scale** to ~1.1 |
| Box lifts with a shadow on hover | Box Shadow on Hover | Click container → Style → Hover sub-tab → **Box Shadow** → add a soft shadow |
| Element fades/slides in when you scroll to it | **Motion Effects → Entrance Animation** | Click element → **Advanced** tab → **Motion Effects** → Entrance Animation → pick **Fade In / Fade In Up / Zoom In** → set Duration & Delay |
| Parallax background (image moves slower than scroll) | **Motion Effects → Scrolling Effects** | Click container → Advanced → Motion Effects → turn on **Scrolling Effects → Vertical Scroll** |
| Sticky header that shrinks on scroll | **Motion Effects → Sticky** (Pro) | Click header container → Advanced → Motion Effects → Sticky = **Top** |
| Number counts up | **Counter** widget | Search widgets → drag **Counter** in → set start/end numbers |
| Logos/slides scroll across | **Carousel / Loop** (or Custom HTML) | Use the **Image Carousel** widget; for an infinite marquee use a Custom HTML widget with scoped CSS |
| Typing / text animation | Pro **Animated Headline**, or Custom HTML | Search widgets → **Animated Headline** |

Always include the **speed/easing** if the analyzer found a `transition`
(e.g. `transition: all 0.3s ease`) — in Elementor that maps to the
**Hover → Transition Duration** field (set it to the same seconds).

If an effect has **no native Elementor control** (custom marquee, fancy SVG
animation, etc.), give Samuel a **WordPress-safe Custom HTML/CSS snippet**:
- Drag the **HTML** widget where the effect goes, paste the snippet.
- The snippet MUST be WordPress-safe per his standing rule: **scoped class
  names, no global CSS resets, no global `overflow`/`height` rules, nothing that
  can leak into the theme.** Wrap styles under one unique parent class.

### Section F — End of Phase 1 (homepage check)

After delivering Sections A–E, end with this short check (friendly tone) and
then **stop and wait** — do not start the inner pages yet:

> "Cuando termines de armar la página de inicio, dime: ¿quedaste contento con
> ella? Si sí, pasamos a crear las páginas internas (About Us, Contacto, etc.).
> Si algo no te quedó igual, mándame una captura de cómo te quedó y lo afinamos
> primero."
> _(When you finish building the homepage, tell me: are you happy with it? If
> yes, we move on to creating the inner pages (About Us, Contact, etc.). If
> something didn't come out matching, send me a screenshot and we fine-tune it
> first.)_

Do **not** dump a giant wall of text up front. Deliver Sections A–F as a clean,
scannable guide. If the page is big, offer to walk him through it **one section
at a time**.

## PHASE 2 — Inner pages (only after he confirms the homepage)

Trigger this phase only when Samuel says the homepage is done / he's happy / he
wants to do the inner pages. Then:

### Step 1 — Ask which pages

> "¿Qué páginas internas necesitas? Dímelas separadas por coma (ej.: About Us,
> Contacto, Productos, Servicios)."
> _(What inner pages do you need? List them comma-separated.)_

### Step 2 — Lock the shared header & footer ONCE

The header (logo + menu) and footer must be **identical on every page**. The
clean beginner way in Elementor is to build them once as global templates:

```
MAKE THE HEADER & FOOTER GLOBAL (do this once)

If you have Elementor Pro:
  - Templates → Theme Builder → Header → build/import your homepage header
    → Publish → set Display Condition to "Entire Site". Do the same for Footer.
  - Now every page you create shows the same header and footer automatically.
    You never rebuild them again.

If you only have free Elementor:
  - On the homepage, select the whole header container → right-click → "Save as
    Template" → name it "Site Header". Do the same for the footer ("Site Footer").
  - On each new inner page, drag in the "Site Header" template at the top and
    the "Site Footer" template at the bottom from the Templates library
    (folder icon in the widget panel).
```

### Step 3 — Build each inner page (body only)

For **each** page Samuel named, give a short blueprint that reuses the homepage
look but with that page's own content:

```
PAGE: [About Us]

1. Pages → Add New → title "About Us" → Template: Elementor Canvas
   (Pro users: pick the template that already shows the global header/footer)
   → Publish → Edit with Elementor.

2. Add the header & footer (skip if global header/footer is already showing).

3. Body sections for this page:
   - [section 1: e.g. page title banner — same colors/fonts as homepage]
   - [section 2: e.g. story text + image]
   - [section 3: e.g. team / values / CTA]
   Reuse the SAME Global Colors and fonts from Phase 1 so it matches.

4. Keep spacing consistent with the homepage (same section padding values).
```

Ask Samuel where each page's content comes from — he can give you text, a
reference URL, or a screenshot, and you analyze it the same way as Phase 1. If
he has no content yet, give sensible placeholder structure he can fill in.

### Step 4 — Link everything through the menu

```
LINK THE PAGES (so the menu works)

If the menu is a WordPress menu (Pro Theme Builder header):
  - Appearance → Menus → create/edit your menu → add each page (Home, About Us,
    Contact, ...) → drag to order → Save. The header menu updates everywhere.

If the menu is built with Elementor nav/buttons:
  - Click each menu link → in the Link field (chain icon) paste that page's URL
    (copy it from Pages → the page → "View"). Do this for every link, on the
    header template so it applies site-wide.
  - Always point "Home" / the logo back to the homepage URL.
```

### Step 5 — Inner-pages finish check

> "Listo. Ya tienes la página de inicio y las internas conectadas. ¿Quieres que
> revisemos alguna, ajustemos colores/textos, o agregamos otra página?"
> _(Done. You now have the homepage and inner pages linked. Want to review any,
> tweak colors/text, or add another page?)_

## Output format

- Deliver the blueprint **in chat** as a clean, scannable guide (this is a
  follow-along manual, not a file he edits). 
- If Samuel asks to keep it, offer to save it as a Markdown or PDF file to
  `/mnt/user-data/outputs/` and present it with `present_files`.
- Keep any code snippets in fenced blocks, WordPress-safe and scoped.

## Bundled files

```
elementor-cloner/
├── SKILL.md                  (this file)
└── scripts/
    └── analyze_page.py       (extracts colors, fonts, spacing, images,
                               hovers, transitions, animations from saved HTML)
```

The analyzer uses only the Python standard library — no installs, no network.
