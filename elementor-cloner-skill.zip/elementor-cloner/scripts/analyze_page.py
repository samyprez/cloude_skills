#!/usr/bin/env python3
"""
analyze_page.py — Extract a rebuild blueprint from a saved web page.

This script does NOT touch the network. Claude fetches the page first
(with the web_fetch tool, asking for raw HTML) and saves it to a local
file. This script then reads that local HTML and pulls out everything
Samuel needs to rebuild the page in Elementor:

  - Color palette (hex + rgb, ranked by how often they appear)
  - Fonts and font sizes
  - Image URLs (so Samuel can download them)
  - Hover effects (CSS :hover rules)
  - Transitions and animations (transition / @keyframes / transform)
  - Rough section structure (header, hero, sections, footer)

Output is a clean Markdown report printed to stdout AND saved next to
the input file, with live progress messages as it runs.

Usage:
  python analyze_page.py /path/to/saved_page.html
  python analyze_page.py /path/to/saved_page.html --out report.md
"""

import argparse
import os
import re
import sys
from collections import Counter
from html.parser import HTMLParser


def progress(pct, msg):
    print(f"[{pct:3d}%] {msg}", flush=True)


# ----------------------------------------------------------------------
# Color extraction
# ----------------------------------------------------------------------
HEX_RE = re.compile(r"#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})\b")
RGB_RE = re.compile(r"rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*(?:,\s*[\d.]+\s*)?\)")


def normalize_hex(h):
    h = h.lower()
    if len(h) == 4:  # #abc -> #aabbcc
        h = "#" + "".join(c * 2 for c in h[1:])
    return h


def extract_colors(text):
    colors = Counter()
    for m in HEX_RE.findall(text):
        colors[normalize_hex(m)] += 1
    for m in RGB_RE.findall(text):
        colors[m.lower().replace(" ", "")] += 1
    # Drop pure white/black noise to the bottom but keep them
    return colors


# ----------------------------------------------------------------------
# Font + size extraction
# ----------------------------------------------------------------------
FONT_FAMILY_RE = re.compile(r"font-family\s*:\s*([^;}{]+)", re.I)
FONT_SIZE_RE = re.compile(r"font-size\s*:\s*([\d.]+(?:px|rem|em|%|pt))", re.I)
GOOGLE_FONT_RE = re.compile(r"fonts\.googleapis\.com/css2?\?family=([^&\"'>]+)", re.I)


def extract_fonts(text):
    families = Counter()
    for m in FONT_FAMILY_RE.findall(text):
        # take the first font in the stack, strip quotes
        first = m.split(",")[0].strip().strip("'\"")
        if first and not first.startswith("var("):
            families[first] += 1
    sizes = Counter(s.lower() for s in FONT_SIZE_RE.findall(text))
    google = []
    for m in GOOGLE_FONT_RE.findall(text):
        google.append(m.split(":")[0].replace("+", " "))
    return families, sizes, google


# ----------------------------------------------------------------------
# Spacing extraction (padding / margin / gap)
# ----------------------------------------------------------------------
SPACING_RE = re.compile(r"(?:padding|margin|gap)[^:;{}]*:\s*([^;}{]+)", re.I)
PX_VAL_RE = re.compile(r"(\d+)px")


def extract_spacing(text):
    vals = Counter()
    for chunk in SPACING_RE.findall(text):
        for px in PX_VAL_RE.findall(chunk):
            n = int(px)
            if n > 0:
                vals[n] += 1
    return vals


# ----------------------------------------------------------------------
# Hover + animation extraction
# ----------------------------------------------------------------------
HOVER_RE = re.compile(r"([^{}]*:hover[^{}]*)\{([^{}]*)\}", re.I)
TRANSITION_RE = re.compile(r"transition\s*:\s*([^;}{]+)", re.I)
TRANSFORM_RE = re.compile(r"transform\s*:\s*([^;}{]+)", re.I)
KEYFRAMES_RE = re.compile(r"@(?:-\w+-)?keyframes\s+([\w-]+)", re.I)
ANIMATION_RE = re.compile(r"animation(?:-name)?\s*:\s*([^;}{]+)", re.I)


def classify_hover(decls):
    d = decls.lower()
    tags = []
    if "scale" in d or "transform" in d and ("1.0" in d or "1.1" in d or "scale" in d):
        if "scale" in d:
            tags.append("grow/shrink (scale)")
    if "translate" in d:
        tags.append("slide/move (translate)")
    if "rotate" in d:
        tags.append("rotate")
    if "opacity" in d or "rgba" in d:
        tags.append("fade / opacity change")
    if "background" in d or "background-color" in d:
        tags.append("background color change")
    if "color" in d and "background" not in d:
        tags.append("text color change")
    if "box-shadow" in d or "shadow" in d:
        tags.append("shadow / lift")
    if "border" in d:
        tags.append("border change")
    if "underline" in d or "text-decoration" in d:
        tags.append("underline")
    if not tags:
        tags.append("style change")
    return tags


def extract_hovers(text):
    hovers = []
    for selector, decls in HOVER_RE.findall(text):
        sel = re.sub(r"\s+", " ", selector).strip()
        hovers.append((sel, classify_hover(decls)))
    return hovers


def extract_animations(text):
    transitions = Counter(re.sub(r"\s+", " ", t).strip() for t in TRANSITION_RE.findall(text))
    transforms = Counter(re.sub(r"\s+", " ", t).strip() for t in TRANSFORM_RE.findall(text))
    keyframes = sorted(set(KEYFRAMES_RE.findall(text)))
    animations = Counter(re.sub(r"\s+", " ", a).strip() for a in ANIMATION_RE.findall(text))
    return transitions, transforms, keyframes, animations


# ----------------------------------------------------------------------
# Structure + images via HTMLParser
# ----------------------------------------------------------------------
class StructureParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.images = []
        self.sections = Counter()
        self.headings = []
        self.nav_links = []
        self._in_heading = None
        self._in_nav = 0
        self._buf = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "img":
            src = a.get("src") or a.get("data-src") or a.get("data-lazy-src")
            if src:
                self.images.append(src)
        if tag in ("section", "header", "footer", "nav", "aside", "article"):
            self.sections[tag] += 1
        if tag == "nav":
            self._in_nav += 1
        if tag in ("h1", "h2", "h3"):
            self._in_heading = tag
            self._buf = []
        # background images in inline style
        style = a.get("style", "")
        if "url(" in style:
            for u in re.findall(r"url\(([^)]+)\)", style):
                self.images.append(u.strip("'\" "))

    def handle_endtag(self, tag):
        if tag == "nav" and self._in_nav > 0:
            self._in_nav -= 1
        if self._in_heading == tag:
            txt = "".join(self._buf).strip()
            if txt:
                self.headings.append((tag, txt[:80]))
            self._in_heading = None
            self._buf = []

    def handle_data(self, data):
        if self._in_heading:
            self._buf.append(data)
        if self._in_nav and data.strip():
            t = data.strip()
            if 1 < len(t) < 30:
                self.nav_links.append(t)


# ----------------------------------------------------------------------
# Report builder
# ----------------------------------------------------------------------
def build_report(html, src_name):
    progress(5, "Reading page...")
    progress(15, "Extracting color palette...")
    colors = extract_colors(html)

    progress(30, "Extracting fonts and sizes...")
    families, sizes, google = extract_fonts(html)

    progress(45, "Measuring spacing (padding/margin/gap)...")
    spacing = extract_spacing(html)

    progress(60, "Finding hover effects...")
    hovers = extract_hovers(html)

    progress(72, "Finding transitions and animations...")
    transitions, transforms, keyframes, animations = extract_animations(html)

    progress(85, "Mapping page structure and images...")
    sp = StructureParser()
    try:
        sp.feed(html)
    except Exception:
        pass

    progress(95, "Writing blueprint...")

    L = []
    L.append(f"# Rebuild Blueprint — `{src_name}`\n")
    L.append("_Auto-extracted by elementor-cloner. Hand this to the Elementor steps in SKILL.md._\n")

    # Colors
    L.append("\n## 1. Color palette (most used first)\n")
    top_colors = [c for c, _ in colors.most_common(14)]
    if top_colors:
        for c, n in colors.most_common(14):
            L.append(f"- `{c}`  (appears ~{n}x)")
    else:
        L.append("- No explicit colors found in this file (CSS may be in an external stylesheet — fetch that too).")

    # Fonts
    L.append("\n## 2. Fonts\n")
    if google:
        L.append("**Google Fonts loaded:** " + ", ".join(sorted(set(google))))
    if families:
        L.append("\n**Font families used (most common first):**")
        for f, n in families.most_common(8):
            L.append(f"- {f}  (~{n}x)")
    else:
        L.append("- No inline font-family found (check the external stylesheet).")
    if sizes:
        L.append("\n**Font sizes seen:** " + ", ".join(s for s, _ in sizes.most_common(12)))

    # Spacing
    L.append("\n## 3. Spacing (common pixel values)\n")
    if spacing:
        common = ", ".join(f"{px}px (~{n}x)" for px, n in spacing.most_common(12))
        L.append("Use these as your padding/margin/gap values in Elementor:")
        L.append(f"- {common}")
    else:
        L.append("- No inline spacing found (likely in the external stylesheet).")

    # Structure
    L.append("\n## 4. Page structure\n")
    if sp.sections:
        L.append("**Landmark blocks found:** " +
                 ", ".join(f"{k} x{v}" for k, v in sp.sections.most_common()))
    if sp.nav_links:
        uniq = list(dict.fromkeys(sp.nav_links))[:12]
        L.append("\n**Menu items (nav):** " + " · ".join(uniq))
    if sp.headings:
        L.append("\n**Headings (top of page = hero):**")
        for tag, txt in sp.headings[:10]:
            L.append(f"- `{tag}` → {txt}")

    # Images
    L.append("\n## 5. Images to download\n")
    imgs = list(dict.fromkeys(sp.images))  # dedupe, keep order
    if imgs:
        L.append(f"Found {len(imgs)} image references. Right-click → Save each, or pull from the live site:")
        for u in imgs[:40]:
            L.append(f"- {u}")
        if len(imgs) > 40:
            L.append(f"- ...and {len(imgs) - 40} more.")
    else:
        L.append("- No <img> or inline background images found in this file.")

    # Hovers
    L.append("\n## 6. Hover effects (recreate in Elementor)\n")
    if hovers:
        seen = set()
        count = 0
        for sel, tags in hovers:
            key = (sel, tuple(tags))
            if key in seen:
                continue
            seen.add(key)
            L.append(f"- `{sel}` → {', '.join(tags)}")
            count += 1
            if count >= 25:
                break
    else:
        L.append("- No :hover rules found inline (check the external stylesheet).")

    # Animations
    L.append("\n## 7. Transitions & animations\n")
    if transitions:
        L.append("**Transitions (speed/easing of hovers):**")
        for t, n in transitions.most_common(8):
            L.append(f"- `{t}`")
    if transforms:
        L.append("\n**Transforms (movement/scale/rotate):**")
        for t, n in transforms.most_common(8):
            L.append(f"- `{t}`")
    if keyframes:
        L.append("\n**Named keyframe animations:** " + ", ".join(keyframes[:15]))
    if animations:
        L.append("\n**Animation declarations:**")
        for a, n in animations.most_common(8):
            L.append(f"- `{a}`")
    if not (transitions or transforms or keyframes or animations):
        L.append("- No animations found inline (check the external stylesheet).")

    progress(100, "Done.")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html_file", help="Path to a saved HTML file (already fetched).")
    ap.add_argument("--out", default=None, help="Where to save the Markdown report.")
    args = ap.parse_args()

    if not os.path.exists(args.html_file):
        print(f"ERROR: file not found: {args.html_file}", file=sys.stderr)
        sys.exit(1)

    with open(args.html_file, "r", encoding="utf-8", errors="ignore") as f:
        html = f.read()

    report = build_report(html, os.path.basename(args.html_file))

    out = args.out or (os.path.splitext(args.html_file)[0] + "_blueprint.md")
    with open(out, "w", encoding="utf-8") as f:
        f.write(report)

    print("\n" + "=" * 60)
    print(report)
    print("=" * 60)
    print(f"\nSaved blueprint to: {out}")


if __name__ == "__main__":
    main()
