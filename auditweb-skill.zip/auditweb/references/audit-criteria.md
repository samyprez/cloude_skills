# Audit Criteria — the four dimensions

Score each dimension **0–100**. Bands: 90–100 Excelente · 75–89 Bueno · 60–74 Regular ·
40–59 Débil · 0–39 Crítico. For every issue, give: **severity** (Alta/Media/Baja),
**the concrete fix**, and **why it matters** in plain business terms.

Don't pad. A short list of real, fixable problems beats a long generic checklist.

---

## 1. Gráfica — Visual & UX design

What makes a site look like it was built this decade, by a pro, and easy to use.

- **First impression / hero** — Is the value proposition clear in 3 seconds? Is there a
  strong headline + subhead + obvious primary CTA above the fold?
- **Visual hierarchy** — Does the eye know where to go? Or is everything the same size,
  centered, and competing?
- **Typography** — Modern, legible font? Sensible scale (not 11px body)? Consistent?
  Outdated system-font-only sites read as "cheap."
- **Color & contrast** — Cohesive palette tied to the brand? Enough contrast to read?
  Or random colors and gray-on-gray text?
- **Whitespace & layout** — Room to breathe, or cramped 2008-style walls of text/boxes?
- **Imagery** — Real, high-quality, on-brand photos? Or stock clichés, blurry uploads,
  inconsistent crops, distorted logos?
- **Consistency** — Buttons, spacing, headings consistent across pages? Or every page
  looks like a different site?
- **Mobile layout** — Does it reflow cleanly, or is it a shrunken desktop with tiny tap
  targets and horizontal scroll? (Most local-business traffic is mobile.)
- **Modern signals** — Rounded/elevated cards, smooth sections, micro-interactions vs.
  flat hyperlinks and default browser styling. Tasteful motion = perceived quality.

**Common quick wins:** stronger hero headline + CTA, bigger readable body text, consistent
spacing, replacing stock/blurry images, adding hover states to buttons and cards.

---

## 2. Operacional — Technical health & performance

Whether the site actually *works* and converts, and won't embarrass the owner.

- **Speed signals** (judge from evidence, recommend PageSpeed for exact numbers):
  - Huge unoptimized hero images, no `loading="lazy"`, no modern formats (WebP/AVIF).
  - Many render-blocking scripts/stylesheets, heavy page-builder bloat, no caching/CDN.
  - Core Web Vitals to name as the targets: **LCP < 2.5s**, **INP < 200ms**, **CLS < 0.1**.
- **Mobile-friendliness** — viewport meta present? tap targets ≥ ~44px? no zoom needed?
- **Security & trust** — HTTPS everywhere? mixed-content warnings? visible contact info,
  business address, hours? trust badges/credentials?
- **Broken things** — dead links, 404s in nav, images that don't load, empty pages.
- **Forms & conversion mechanics** — Does the contact form work and confirm submission?
  Is the phone a tappable `tel:` link? WhatsApp / booking obvious? Is there ANY clear CTA
  on every page, or do dead-end pages leak visitors?
- **Navigation/IA** — Can a visitor find services, prices, and contact in one or two taps?
  Logical menu, working footer, breadcrumbs where useful.
- **Analytics & pixels** — Any analytics installed (so the owner can measure)? (Note it;
  don't over-index.)

**Common quick wins:** compress hero images + lazy-load, make phone a `tel:` link, add a
sticky "Llámanos / Cotiza" CTA, fix broken nav links, ensure the form actually sends.

---

## 3. SEO clásico — classic search optimization

Getting found on Google the traditional way.

- **Title tags** — Unique, descriptive, ~50–60 chars, keyword + location for local biz?
  Or "Home | Inicio" / empty / duplicated across pages?
- **Meta descriptions** — Present, compelling, unique per page?
- **Headings** — Exactly one `<h1>` per page, logical H2/H3 with real keywords?
- **Image alt text** — Descriptive `alt` on meaningful images (also helps accessibility)?
- **URL structure** — Clean, readable, lowercase, hyphenated? Or `?p=4471` junk?
- **Internal linking** — Pages link to each other so Google (and AI) can crawl & connect topics?
- **XML sitemap & robots.txt** — Present, valid, not accidentally blocking the whole site?
- **Indexability** — `noindex` left on by mistake? canonical tags sane? (Samuel knows the
  pain of index bloat — flag anything that looks like crawl/index waste.)
- **Structured data (schema.org JSON-LD)** — Organization / LocalBusiness, Breadcrumb,
  Product, Article, Review, FAQ? This feeds BOTH Google rich results and AI engines.
- **Content depth** — Thin one-paragraph pages vs. genuinely useful content that answers
  what customers ask.
- **Local SEO** (for local businesses) — Google Business Profile claimed & complete? NAP
  (Name/Address/Phone) consistent on-site and matching GBP? Embedded map? Reviews shown?

**Common quick wins:** rewrite title tags with keyword+city, add meta descriptions, add
LocalBusiness + FAQ schema, add alt text, claim/optimize Google Business Profile.

---

## 4. Buscadores de IA — GEO / AEO (the differentiator)

How to get the site **cited and recommended by AI engines** — ChatGPT, Gemini, Perplexity,
Copilot, and Google AI Overviews. This is the section most competitor audits skip, so make
it shine. (Grounded in 2026 best practices.)

**Why it matters now (use a line like this in the report):** AI assistants increasingly
answer questions *without* sending a click, naming only the few sources they trust. If the
site isn't structured for AI extraction, it's invisible in that new channel — and that
channel is growing fast.

**A. Let the AI crawlers in (technical access)**
- `robots.txt` must not block AI bots (e.g. `GPTBot`, `ChatGPT-User`, `PerplexityBot`,
  `Google-Extended`). Many sites block them by accident.
- **Cloudflare warning**: Cloudflare now blocks AI bots by default on many plans — if the
  client uses Cloudflare, their AI traffic may already be shut off. Flag it.
- Important content must be **server-side rendered**, not hidden behind JavaScript, logins,
  or paywalls. AI can't cite what it can't read.

**B. Structure for extraction**
- **Answer-first**: each key section opens with a direct, self-contained answer, *then*
  context. The first ~150–200 tokens of a page carry the most weight.
- **Definitional opening** for entity/brand pages: a clean "[Brand] is a [category] that
  [differentiator]" sentence near the top (e.g. "BM Painting es una empresa de pintura
  residencial en Toronto que…").
- **Question-based headings** matching how people actually ask ("¿Cuánto cuesta…?",
  "How long does X take?") with the answer right under each.
- **FAQ section** answering the real top customer questions — and mark it up with **FAQ
  schema** (JSON-LD).
- **Scannable formats**: short paragraphs, bullet lists, numbered steps, and **comparison
  tables** ("X vs Y", pricing, options) — AI lifts these cleanly.

**C. Earn the citation (authority & trust signals)**
- **Factual density**: specific numbers, stats, dates, named credentials, prices, service
  areas. Princeton research found citing sources, adding statistics, and including
  quotations can lift AI visibility ~30–40% vs. unoptimized content.
- **Freshness**: visible "Última actualización / Last updated" dates and a matching
  `dateModified` in schema. AI engines favor fresh sources; stale pages lose citation priority.
- **Entity clarity & consistency**: same business name, address, phone everywhere; clear
  About page; links to/from authoritative profiles (GBP, social, directories).
- **`llms.txt`**: consider adding an `llms.txt` at the root to guide AI systems to the most
  important pages (an emerging but cheap, low-risk signal).
- **Schema everywhere**: Organization/LocalBusiness, FAQ, Product/Service, Review, Article.
  Same JSON-LD that helps Google also helps RAG pipelines.

**Common quick wins:** add an FAQ section + FAQ schema, add LocalBusiness/Organization
schema, add "last updated" dates, unblock AI crawlers in robots.txt, rewrite the hero/intro
as a clear definitional answer, add an `llms.txt`.

---

## Scoring guidance

- Weight by what actually moves the needle for *this* business type. A local contractor
  lives or dies on mobile speed, clear CTA, GBP, and local + AI answers; a content site
  leans more on schema, freshness, and internal linking.
- Be fair but honest — a too-generous score kills the pitch; a brutal score with clear
  fixes builds trust. The sweet spot: "here's exactly what's holding you back, and it's
  very fixable (by us)."
