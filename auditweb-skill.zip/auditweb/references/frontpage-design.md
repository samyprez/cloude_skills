# Front Page Design — the pitch page

Build a **single self-contained HTML file** that makes the client say "wow." It must feel
like *their* business, leveled up — not a generic template. The whole point is to **show,
not tell**: the demo is living proof of the audit.

Deliver to `/mnt/user-data/outputs/` and present it. Keep CSS + minimal JS inline so the
file opens anywhere by double-click.

---

## Core principles

1. **Reuse the client's real content & brand.** Pull their logo, colors, fonts (or close
   web-safe matches), headline, services, testimonials, contact info, and photos from the
   crawl. If a real asset is missing, use a tasteful placeholder and note it — never paint
   the client in Amazing Solutions' own teal/lime.
2. **Compacto.** A tight one-page flow that scrolls beautifully. Every section earns its
   place. No filler, no 12 redundant blocks. Think 6–8 purposeful sections max.
3. **Mobile-first.** Design the small screen first, enhance up. Real thumbs, 16px+ body,
   ≥44px tap targets, no horizontal scroll, fast hero image.
4. **Tasteful motion.** Smooth and refined, never gaudy. Motion should feel premium and
   intentional. Always respect `prefers-reduced-motion`.
5. **Fix what the audit found.** If the audit said "no clear CTA," the demo has a great one.
   If it said "weak hero," the demo's hero is strong. The demo answers the audit.

**Copy is in English by default** (Samuel's preference for pitch front pages), even when the
audit is in Spanish — unless he says otherwise. Pull the client's real *content/meaning*
from their site and rewrite it sharp in English.

---

## Aesthetic direction (the "modern website inspiration" look)

Samuel's standing reference is the current "modern website inspiration" aesthetic (the kind
curated on Pinterest/Awwwards). That live feed can't be crawled, but here's the direction it
represents, current for 2026. Lean into these — tastefully, and **always matched to the
client's industry**:

- **Typography as the hero.** Oversized, confident headlines with generous spacing; strong
  type can carry a hero with little or no imagery. Variable fonts where it helps. Optional
  *subtle* kinetic touches (weight/letter-spacing shift on scroll or hover) — never gimmicky.
- **Bold accent on neutral.** One saturated accent color against a clean neutral base; the
  contrast is the design tool. Avoid saturated-everything (then nothing stands out).
- **Bento grids.** Modular, varied-size cards for services/features — modern and scannable.
- **Refined glass & depth.** Mature glassmorphism, soft layering, gentle shadows — not the
  heavy 2021 drop-shadow soft-UI. Optional dark-first section for contrast.
- **Purposeful micro-interactions.** Motion is baseline now: hover feedback, scroll-reveal,
  smooth section transitions. It should feel alive but calm, and respect performance.
- **Generous whitespace + bite-sized content.** Room to breathe; short scannable blocks
  (also helps mobile and AI extraction).

**Match the vibe to the business** — this is the key judgment call:
- Trades / home services / medical / finance / legal → polished, trustworthy, clean; bold
  but conservative. **Avoid neo-brutalism here** (it reads as untrustworthy for these).
- Creative agencies / fashion / events / nightlife / tech → more expressive: bigger type,
  stronger color, neo-brutalist or editorial touches are fair game.

The trap to avoid: generic AI-default layouts. Standing out in 2026 takes intention and a
clear point of view — pick two or three of these moves and execute them with craft, rather
than piling on every trend.

---

## Recommended compact structure

A proven order (adapt to the business — don't make every site identical):

1. **Sticky nav** — logo left, 3–5 links + one primary CTA button right; condenses/
   shadows on scroll; mobile hamburger.
2. **Hero** — big clear headline (their value prop, sharpened), one-line subhead, primary
   CTA + secondary link, a strong on-brand image or subtle gradient/mesh background.
   Optional trust line ("+10 años · 500+ clientes · Toronto").
3. **Trust bar** — logos, certifications, star rating, or quick stat counters.
4. **Services / What we do** — 3–4 cards with icon, title, one line, hover lift. (Mirror
   the client's actual services.)
5. **Why us / Benefits** — a few differentiators, or a clean before/after or feature row.
6. **Social proof** — 1–3 real testimonials (from their site) + photos/names if available.
7. **About (short)** — one tight paragraph + one image; humanizes the brand.
8. **Final CTA band** — bold call-to-action with phone (`tel:`), form, or WhatsApp.
9. **Footer** — NAP, hours, map link, socials, copyright.

Drop sections the business doesn't need. Compact > complete.

---

## Visual system (set these as CSS variables at the top)

```css
:root{
  --brand: /* primary from client */;       --brand-600: /* darker */;
  --accent: /* secondary/CTA */;             --ink:#0f1115; --muted:#5b6470;
  --bg:#ffffff; --surface:#f6f8fa; --line:rgba(15,17,21,.08);
  --radius:16px; --shadow:0 10px 30px -12px rgba(15,17,21,.18);
  --ease:cubic-bezier(.22,.61,.36,1);
}
* { box-sizing:border-box; }
html { scroll-behavior:smooth; }
body { margin:0; font-family:Inter,Manrope,system-ui,sans-serif; color:var(--ink);
       line-height:1.6; -webkit-font-smoothing:antialiased; }
img { max-width:100%; display:block; }
```

- Type scale via `clamp()` so it's fluid: `font-size:clamp(2rem,5vw,3.5rem)` for the hero.
- One accent color does the heavy lifting; everything else is ink/muted/surface.
- Generous spacing: section padding `clamp(3rem,8vw,6rem)`.
- Cards: white surface, soft border, `--radius`, subtle `--shadow`.

(If the client's brand is unknown, pick a tasteful palette that fits their industry — warm
and trustworthy for trades/home services, clean and clinical for medical, bold for events.)

---

## Motion & hover library (copy, tune, use sparingly)

**Scroll-reveal** (IntersectionObserver, graceful if JS off):
```css
.reveal{opacity:0;transform:translateY(24px);transition:opacity .7s var(--ease),transform .7s var(--ease);}
.reveal.in{opacity:1;transform:none;}
@media (prefers-reduced-motion:reduce){.reveal{opacity:1;transform:none;transition:none;}}
```
```js
const io=new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&e.target.classList.add('in')),{threshold:.15});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
```

**Button** — lift + sheen on hover:
```css
.btn{padding:.9rem 1.5rem;border-radius:999px;background:var(--accent);color:#fff;font-weight:600;
     border:0;cursor:pointer;transition:transform .25s var(--ease),box-shadow .25s var(--ease);}
.btn:hover{transform:translateY(-2px);box-shadow:0 12px 24px -8px var(--accent);}
.btn:active{transform:translateY(0);}
```

**Card** — hover lift + border glow:
```css
.card{background:var(--bg);border:1px solid var(--line);border-radius:var(--radius);
      padding:1.5rem;transition:transform .3s var(--ease),box-shadow .3s var(--ease),border-color .3s var(--ease);}
.card:hover{transform:translateY(-6px);box-shadow:var(--shadow);border-color:color-mix(in srgb,var(--brand) 35%,transparent);}
```

**Underline-grow link**:
```css
.link{position:relative;text-decoration:none;color:var(--ink);}
.link::after{content:"";position:absolute;left:0;bottom:-3px;height:2px;width:0;background:var(--accent);transition:width .3s var(--ease);}
.link:hover::after{width:100%;}
```

**Sticky nav condense on scroll**:
```js
addEventListener('scroll',()=>document.querySelector('header').classList.toggle('scrolled',scrollY>20));
```
```css
header{transition:background .3s,box-shadow .3s,padding .3s;}
header.scrolled{background:rgba(255,255,255,.85);backdrop-filter:blur(10px);box-shadow:0 1px 0 var(--line);padding-block:.5rem;}
```

Other tasteful options: animated stat counters, a subtle gradient-mesh or image hero with
a soft overlay, image `scale(1.04)` on card hover (with `overflow:hidden`), gentle parallax.
**Restraint is the brief** — two or three motion ideas done well beat ten competing ones.

---

## Quality bar before delivering

- Looks great at **375px** and at **1280px+**. No horizontal scroll on mobile.
- Hero readable in 3 seconds; primary CTA obvious; phone is a `tel:` link.
- Real client content throughout (not "Lorem ipsum" — pull their actual words).
- Embeds bake in basic SEO/AEO from the audit: good `<title>`, meta description,
  one `<h1>`, `alt` on images, and an `Organization`/`LocalBusiness` + `FAQ` JSON-LD block
  if you included a FAQ. (Easy way to make the demo itself score well.)
- `prefers-reduced-motion` respected. No console errors.

## Optional power-ups
- For deeper industry-specific structure and anti-template variety, run Samuel's
  **`mobile-first-master-builder`** skill to drive the build.
- For a pre-handoff accessibility + mobile-typography pass, run his
  **`wave-accessibility-auditor`** skill.
- If the client needs the page IN their WordPress (not just a demo), rebuild it scoped/
  isolated (Shadow DOM or scoped classes, no global resets) per Samuel's WordPress rule.
