# Audit report template

Use this as the SKELETON for the audit deliverable. Write it in the **client's language**
(Spanish by default). Fill the brackets. Keep it professional and benefit-focused — it's a
sales document, not an engineering ticket. Replace the example Spanish labels with English
if the client site is English.

---

# Auditoría web — [Nombre del cliente / dominio]
*Preparado por Amazing Solutions · [fecha]*

## Resumen ejecutivo
[3–5 oraciones que un dueño ocupado entiende: qué tan bien está el sitio hoy, las 2–3
oportunidades más grandes, y qué se gana al arreglarlas (más clientes, mejor posición en
Google y en buscadores de IA).]

**Puntuaciones (0–100):**

| Dimensión | Puntuación | Estado |
|---|---|---|
| 🎨 Gráfica / Diseño | [xx] | [Bueno/Regular/Débil] |
| ⚙️ Operacional / Técnico | [xx] | [...] |
| 🔍 SEO (Google) | [xx] | [...] |
| 🤖 Buscadores de IA (GEO/AEO) | [xx] | [...] |
| **Global** | **[xx]** | **[...]** |

## Prioridades — empieza por aquí
*Ordenadas por impacto vs. esfuerzo. Las primeras son "victorias rápidas".*

| # | Acción | Impacto | Esfuerzo | Dimensión |
|---|---|---|---|---|
| 1 | [arreglo concreto] | Alto | Bajo | [...] |
| 2 | [...] | [...] | [...] | [...] |
| … | | | | |

---

## 1. Gráfica — Diseño y experiencia
[2–3 hallazgos clave. Por cada uno: el problema, la severidad, el arreglo concreto, y por
qué importa para el negocio. Sé específico — "el héroe usa una imagen de 3 MB sin comprimir"
no "optimiza las imágenes".]

## 2. Operacional — Salud técnica y rendimiento
[Igual: hallazgos concretos. Señala velocidad (con la nota de medir en PageSpeed para cifras
exactas), móvil, formularios, CTAs, enlaces rotos, seguridad.]

## 3. SEO — Posicionamiento en Google
[Títulos, metadescripciones, encabezados, alt, sitemap, schema, indexación, SEO local /
Google Business Profile.]

## 4. Buscadores de IA — Cómo aparecer en ChatGPT, Gemini, Perplexity y Google AI
[**Destaca esta sección** — la mayoría de auditorías la ignoran. Explica en una línea por
qué importa (la IA responde sin clics y solo cita a las fuentes que confía). Luego los
arreglos: acceso de crawlers de IA, estructura "respuesta primero", FAQ + schema, datos y
fechas de actualización, llms.txt, consistencia de la marca.]

---

## Próximos pasos
[Cierre suave que posiciona a Amazing Solutions como el equipo ideal para ejecutar esto.
Menciona que ya preparaste una propuesta de nuevo front page para que vean el potencial.
Una invitación clara a conversar / cotizar.]

*Amazing Solutions — Soluciones digitales · amazingsolutions.ca*
