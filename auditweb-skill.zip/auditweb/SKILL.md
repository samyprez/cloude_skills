---
name: auditweb
description: >-
  Turn any website URL into a client-winning pitch package: (1) an expert
  developer audit covering visual/graphic design, operational & technical health,
  classic SEO, and AI-search optimization (GEO/AEO for ChatGPT, Gemini, Perplexity,
  Google AI Overviews), with prioritized, concrete fixes for maximum exposure and
  ranking — and (2) a polished, compact, modern redesigned front page built from
  the client's OWN content and brand, with tasteful hover effects and transitions,
  meant to impress the client and close the deal. Trigger this skill IMMEDIATELY
  whenever Samuel gives a website URL and asks to audit, analyze, review, improve,
  redesign, or "pitch" it — including phrases like "audita esta página",
  "analiza este website", "revisa esta web y dame mejoras", "hazme un front page
  para impresionar al cliente", "pitch para cliente", "auditweb", "webpitch",
  "audit this site", "analyze this site for SEO and AI search", or any time he
  pastes a client URL with intent to win the account. Use this even when he only
  asks for the audit OR only the front page — it handles either half.
---

# Web Audit & Pitch

This skill produces a **sales pitch package** for Samuel's agency (Amazing Solutions):
an expert audit of a prospective client's website plus a redesigned front page built
from the client's own content. The goal is always the same — **make the client say
"wow, I need to hire you."**

Two deliverables, produced in this order:
1. **Auditoría / Audit** — what's wrong and how to fix it (visual, operational, SEO, AI-search).
2. **Front page pulido / Pitch front page** — a polished, compact, modern homepage demo.

Samuel may ask for both (default) or just one. Read his request and deliver accordingly.

---

## Working defaults (state them, don't ask unless he objects)

- **Language**:
  - **Front page → English by default.** Samuel pitches across Canada/US and a sharp
    English homepage reads as premium. Build the demo in English unless he says otherwise
    (e.g. "hazlo en español" or the client is strictly Spanish-only).
  - **Audit report → match the client's site language**, Spanish fallback when unclear
    (most of his clients are the Hispanic/Dominican market). He can override either anytime.
- **Front page = standalone demo**: a single self-contained HTML file meant to be
  *shown* to the client to win the deal. Because it is a standalone demo (its own
  document, not injected into a live WordPress page), normal full-page CSS is fine here.
  **If Samuel says it's going INTO the client's WordPress**, switch to scoped/isolated
  mode (Shadow DOM or scoped classes, no global resets) per his standing WordPress rule.
- **Brand colors come from the CLIENT'S site**, not from Samuel's own brands. Never
  paint a client's page in Amazing Solutions teal/lime unless the client's brand is
  actually those colors.
- **Show live progress** during the crawl and the build — counters and status lines
  ("Página 3/7 analizada…", "Construyendo hero… 40%"). Samuel always wants to see
  the machine working.
- **Keep chat updates warm and simple** (like explaining to a bright 5th-grader), but
  the deliverables themselves must be **professional and client-facing**.

If two or more of these defaults are genuinely ambiguous for a given job, ask ONE short
question. Otherwise proceed and state the assumptions in a line at the top.

---

## Phase 1 — Gather (crawl the client site)

Goal: collect everything needed to both audit AND rebuild the site. Announce progress.

1. **Fetch the homepage** with `web_fetch`. Then find the inner pages from the nav menu,
   footer links, and `/sitemap.xml`. Fetch the **3–7 most important inner pages**
   (services/servicios, about/nosotros, contact/contacto, products, pricing, blog index).
   Don't fetch dozens — get a representative picture.

2. **As you crawl, extract and save** (keep notes in the workspace):
   - **Content/copy**: headline, value proposition, list of services/products, prices,
     testimonials, team/about text, contact info (phone, email, address, hours, map),
     social links, certifications/credentials, languages offered.
   - **Brand assets**: logo URL, dominant colors (read inline styles / CSS / hero image),
     fonts in use, photography style, any icons.
   - **CTAs and conversions**: what actions the site asks for (call, form, WhatsApp, book).

3. **Technical probes** (cheap fetches — do these too):
   - `/robots.txt`, `/sitemap.xml`, `/llms.txt` — exist? sane? blocking AI crawlers?
   - Homepage `<head>`: title, meta description, viewport, canonical, Open Graph,
     `<html lang>`, structured data (`application/ld+json`).
   - Heading structure (single H1? logical H2/H3?), image `alt` coverage, HTTPS,
     mobile viewport, any obvious render-blocking or JS-only content.

**Honesty about measurement**: this environment fetches HTML, it does not run a real
browser or Lighthouse. So judge performance/UX from **observable evidence** (page weight,
number/size of images, render-blocking scripts, inline-style sprawl, lack of lazy-loading)
and **recommend** the client run Google PageSpeed Insights for exact Core Web Vitals.
Never invent a precise score (e.g. "LCP is 4.2s") you didn't measure — say "likely slow
because the hero loads a 3 MB uncompressed image" instead. Credibility wins pitches.

If a site can't be fetched (blocked, login wall, JS-only SPA returning little HTML),
say so plainly and tell Samuel what you *can* still do (e.g. audit from what's visible +
rebuild from a screenshot he provides).

---

## Phase 2 — Audit (the four dimensions)

**Read `references/audit-criteria.md` now.** It contains the full checklist and scoring
bands for all four dimensions. Work through each one against what you gathered:

1. **Gráfica / Visual & UX** — design quality, hierarchy, typography, color, imagery,
   whitespace, modern feel, mobile layout, branding consistency.
2. **Operacional / Technical & Performance** — speed signals, broken things, forms that
   work, navigation, security, conversion mechanics (CTAs, contact, trust).
3. **SEO clásico** — titles, meta, headings, alt text, internal links, sitemap, schema,
   indexability, content depth, local SEO (Google Business Profile).
4. **Buscadores de IA / GEO-AEO** — the part Samuel specifically cares about: getting
   cited by ChatGPT, Gemini, Perplexity, Copilot, and Google AI Overviews. This is the
   differentiator that makes the pitch feel cutting-edge.

For every issue: name it, rate **severity** (🔴 Crítico / 🟡 Importante / 🟢 Menor — or
Alta/Media/Baja in text), and give the **concrete fix** (what to change, not vague advice).
Give each dimension a **score out of 100** so the client sees a scoreboard.

---

## Phase 3 — Audit report

**Use the template in `assets/report-template.md`** as the structure. Produce a clean,
professional report **in the client's language**. It should read like it came from a
senior agency, not a checklist dump. Key sections:

- **Resumen ejecutivo** — 3–5 sentences a busy owner understands, plus the four scores.
- **Tabla de prioridades** — quick wins (alto impacto / bajo esfuerzo) first, then bigger fixes.
- **Hallazgos por dimensión** — the four sections, each with issues + fixes + why it matters.
- **Sección de IA** — call this out prominently; most competitors' audits ignore it.
- **Próximos pasos** — a soft close that positions Amazing Solutions as the team to do it.

Save the report as a Markdown file in `/mnt/user-data/outputs/` so Samuel can hand it over.
(If he asks for a polished PDF or Word version, use the `pdf` or `docx` skill.)

---

## Phase 4 — Pitch front page

**Read `references/frontpage-design.md` now** for the design system, modern-element
library, hover/transition snippets, the compact page structure, and the **aesthetic
direction** (Samuel's standing inspiration is the current "modern website inspiration"
look — 2026 trends like oversized expressive type, bento grids, refined glass, bold accent
on neutral, purposeful micro-interactions). If Samuel drops specific reference
images/screenshots/pins he likes, match those over the generic direction.

Build a **single self-contained HTML file** (CSS + minimal JS inline) that:
- Reuses the client's **real content and brand** (their logo, colors, services, copy,
  contact, testimonials) — so it feels like *their* site, leveled up, not a generic template.
- Is **mobile-first**, fast, and **compact** — a tight one-page flow that scrolls
  beautifully, not a bloated mega-site. "Compacto" = every section earns its place.
- Has **modern elements and tasteful motion**: smooth scroll-reveal, refined hover states
  on cards/buttons/nav, subtle gradients or glass accents — polished, never gaudy.
- Fixes the biggest issues found in the audit (so the demo *is* the proof of value).

Show build progress. When done, save to `/mnt/user-data/outputs/` and use `present_files`.

**Power-ups (optional, mention to Samuel):**
- For a fuller multi-section or multi-page build, pair with his
  `mobile-first-master-builder` skill (industry research + anti-template structure).
- Before final handoff, his `wave-accessibility-auditor` skill can do an accessibility
  + mobile-typography pass so the demo is bulletproof.

---

## Phase 5 — Wrap-up

End with a short, friendly summary for Samuel:
- The four scores and the single biggest opportunity.
- Both files presented.
- Offer the obvious next moves: a WordPress-ready version of the front page, a PDF of the
  audit to email the client, the full multi-page build, or Spanish/English swap.

Keep it tight. Samuel communicates briefly — match that energy.
